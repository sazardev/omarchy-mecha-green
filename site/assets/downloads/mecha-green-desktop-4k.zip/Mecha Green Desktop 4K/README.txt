Mecha Green Desktop 4K

Mecha Green for Omarchy — MIT licensed.
Artwork: https://github.com/sazardev/omarchy-mecha-green
All wallpapers are rendered from the original SVG sources.
